CREATE TABLE IF NOT EXISTS `ext_example_a` (
   `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
   `test` int(11) DEFAULT NULL,
   PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ext_example_b` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `test` int(11) DEFAULT NULL,
   PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

