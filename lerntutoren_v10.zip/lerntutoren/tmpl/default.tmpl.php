<div class="box">
	<div class="box-body">
		<div id="app"></div>
	</div>
</div>